---
id: PLAN-002
title: PRAVAH P2 — Information, sensor placement, and causal forecasting
status: active
question: null
skills: []
author_type: human
author_name: null
author_model: null
created_at: '2026-11-10T20:31:20-05:00'
updated_at: '2026-11-10T20:31:20-05:00'
completed_at: null
---

# PLAN-002 · PRAVAH P2 — Information, sensor placement, and causal forecasting

## Objective

Measure observability and temporal information; implement and compare placement criteria and forecast-oriented causal filtering on fixed, leakage-free synthetic benchmarks.

## Success Criteria

E04–E11 verified using the promoted P1 baseline, preregistered metrics and real local/HPC run evidence; information, placement, Kalman, and forecast claims reviewed with uncertainty and negative results retained.

## Context

<!-- research:generated — everything below is regenerated; edits here are ignored -->

## Tasks (0/0 done)

_(no tasks yet)_

_Author: human_
