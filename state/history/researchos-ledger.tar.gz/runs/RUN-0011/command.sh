#!/bin/bash
# RUN-0011 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
python3 scripts/e03_derivation_checks.py
