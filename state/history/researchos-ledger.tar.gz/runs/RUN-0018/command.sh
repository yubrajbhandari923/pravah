#!/bin/bash
# RUN-0018 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
env PRAVAH_ROOT=/home/yubraj/research/pravah/experiments/EXP-005 python3 /tmp/audit/e04_audit_mc.py
