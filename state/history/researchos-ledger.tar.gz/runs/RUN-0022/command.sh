#!/bin/bash
# RUN-0022 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
python3 scripts/e05_duration.py B
