#!/bin/bash
# RUN-0003 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
env PYTHONPATH=src python3 -W ignore -m pytest -q tests/test_forward_oracles.py tests/test_forward_verification.py
