#!/bin/bash
# RUN-0004 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
python /tmp/diag/modeq.py
