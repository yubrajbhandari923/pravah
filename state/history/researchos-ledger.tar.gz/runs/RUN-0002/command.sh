#!/bin/bash
# RUN-0002 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
python3 -m pytest tests/test_forward_oracles.py -q -rs
