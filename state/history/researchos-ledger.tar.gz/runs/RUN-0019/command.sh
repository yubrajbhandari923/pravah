#!/bin/bash
# RUN-0019 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
python3 -c '
import numpy as np
for n,r in [(1,.8),(5,.8),(24,.8),(168,.8),(10,0.0)]:
    i=np.arange(n);R=r**abs(i[:,None]-i[None,:]);o=np.ones(n)
    print(n,r,o@np.linalg.solve(R,o),(n*(1-r)+2*r)/(1+r))
'
