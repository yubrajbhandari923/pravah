#!/bin/bash
# RUN-0005 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
/home/yubraj/.local/share/uv/tools/research-panel/bin/python docs/research/oracle_ii_derivation.py
