#!/bin/bash
# RUN-0007 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
python3 /tmp/t009/gen_benchmark.py configs/benchmark-v1.yaml
