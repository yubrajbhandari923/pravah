#!/bin/bash
# RUN-0017 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
python3 scripts/e04_footprints.py
