#!/bin/bash
# RUN-0008 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
env PYTHONPATH=src python3 -m pytest -q tests/test_benchmarks.py
