#!/bin/bash
# RUN-0006 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
/home/yubraj/research/pravah/.venv/bin/python scripts/e01_verification.py
