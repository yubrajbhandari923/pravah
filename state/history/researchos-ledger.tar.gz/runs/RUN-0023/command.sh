#!/bin/bash
# RUN-0023 — re-run this command (paths relative to the project root)
cd "$(dirname "$0")/../../.." && cd .
python3 scripts/e05_report.py /home/yubraj/research/pravah/ledger/.research/runs RUN-0020 RUN-0022
